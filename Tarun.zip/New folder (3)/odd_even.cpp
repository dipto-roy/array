#include <bits/stdc++.h>
using namespace std;
int main()
{
    int arr[10];
    int i,odd=0,even=0;


    cout<<"\nEnter elements of the array\n\n";
    for(i=0; i<10; i++)
    {

        cin>>arr[i];
    }
    for(i=0; i<10; i++)
    {
        if(arr[i]%2==0)
        {
            even++;
        }
        else
        {
            odd++;
        }
    }
    cout<<"\nTotal even numbers of an array :"<<even<<"\n";
    cout<<"Total odd numbers of an array : "<<odd;

    return 0;
}
