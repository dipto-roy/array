#include <bits/stdc++.h>
using namespace std;


void printevenodd(int cur, int limit);

int main()
{
    int lowerLimit, upperLimit;


    cout<<"Enter lower limit: ";
    cin>>lowerLimit;
    cout<<"Enter upper limit: ";
    cin>>upperLimit;

    cout<<"odd Numbers from "<<lowerLimit <<" to "<<upperLimit<<endl;
    printevenodd(lowerLimit, upperLimit);

    return 0;
}




void printevenodd(int cur, int limit)
{
    if(cur > limit)
        return;

    cout<<cur<<endl;


    printevenodd(cur + 2, limit);
}

